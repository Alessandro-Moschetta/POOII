package br.edu.ifsc.maquinavendas;

import java.text.DecimalFormat;
import java.util.List;
import javax.swing.ImageIcon;
import java.util.stream.Collectors;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

public class TelePrincipal extends javax.swing.JFrame {

    List<Produto> prods;
    List<FormaPgto> formas;

    public TelePrincipal() {
        initComponents();
        carregaProdutos();
    }

    public void carregaProdutos() {
        try {
            prods = Produto.buscaProdutos();

            if (prods.size() > 0) {
                ImageIcon img1 = new ImageIcon(prods.get(0).getImagem());
                lblimg1.setIcon(img1);
                lblCod1.setText(String.valueOf(prods.get(0).getId()));
                lblDesc1.setText(prods.get(0).getDescr());                
                String padrao = "#,###.00";
                DecimalFormat df = new DecimalFormat(padrao);
                lblValor1.setText("R$ " + String.valueOf(df.format(prods.get(0).getPreco())));
            }
            if (prods.size() > 1) {
                ImageIcon img2 = new ImageIcon(prods.get(1).getImagem());
                lblimg2.setIcon(img2);
                lblCod2.setText(String.valueOf(prods.get(1).getId()));
                lblDesc2.setText(prods.get(1).getDescr());
                String padrao = "#,###.00";
                DecimalFormat df = new DecimalFormat(padrao);
                lblValor2.setText("R$ " + String.valueOf(df.format(prods.get(1).getPreco())));
            }
            if (prods.size() > 2) {
                ImageIcon img3 = new ImageIcon(prods.get(2).getImagem());
                lblimg3.setIcon(img3);
                lblCod3.setText(String.valueOf(prods.get(2).getId()));
                lblDesc3.setText(prods.get(2).getDescr());
                String padrao = "#,###.00";
                DecimalFormat df = new DecimalFormat(padrao);
                lblValor3.setText("R$ " + String.valueOf(df.format(prods.get(2).getPreco())));
            }
            if (prods.size() > 3) {
                ImageIcon img4 = new ImageIcon(prods.get(3).getImagem());
                lblimg4.setIcon(img4);
                lblCod4.setText(String.valueOf(prods.get(3).getId()));
                lblDesc4.setText(prods.get(3).getDescr());
                String padrao = "#,###.00";
                DecimalFormat df = new DecimalFormat(padrao);
                lblValor4.setText("R$ " + String.valueOf(df.format(prods.get(3).getPreco())));
            }
        } catch (Exception e) {
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblimg1 = new javax.swing.JLabel();
        lblimg2 = new javax.swing.JLabel();
        lblimg3 = new javax.swing.JLabel();
        lblCod1 = new javax.swing.JLabel();
        lblCod2 = new javax.swing.JLabel();
        lblCod3 = new javax.swing.JLabel();
        lblDesc1 = new javax.swing.JLabel();
        lblDesc2 = new javax.swing.JLabel();
        lblDesc3 = new javax.swing.JLabel();
        lblValor1 = new javax.swing.JLabel();
        lblValor2 = new javax.swing.JLabel();
        lblValor3 = new javax.swing.JLabel();
        lblimg4 = new javax.swing.JLabel();
        lblCod4 = new javax.swing.JLabel();
        lblDesc4 = new javax.swing.JLabel();
        lblValor4 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        edtCodigoProd = new javax.swing.JTextField();
        lblprodsel = new javax.swing.JLabel();
        btnComprar = new javax.swing.JButton();
        btnGerenciar = new javax.swing.JButton();
        lblimg5 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Tela Principal");

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(null));
        jPanel1.setFont(new java.awt.Font("Microsoft Tai Le", 1, 14)); // NOI18N

        lblimg1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblimg1.setBorder(javax.swing.BorderFactory.createLineBorder(null));

        lblimg2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblimg2.setBorder(javax.swing.BorderFactory.createLineBorder(null));

        lblimg3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblimg3.setBorder(javax.swing.BorderFactory.createLineBorder(null));

        lblCod1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCod1.setText("lblCod1");
        lblCod1.setBorder(javax.swing.BorderFactory.createLineBorder(null));

        lblCod2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCod2.setText("lblCod2");
        lblCod2.setBorder(javax.swing.BorderFactory.createLineBorder(null));

        lblCod3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCod3.setText("lblCod3");
        lblCod3.setBorder(javax.swing.BorderFactory.createLineBorder(null));

        lblDesc1.setForeground(new java.awt.Color(0, 0, 204));
        lblDesc1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDesc1.setText("lblDesc1");
        lblDesc1.setBorder(javax.swing.BorderFactory.createLineBorder(null));

        lblDesc2.setForeground(new java.awt.Color(0, 0, 204));
        lblDesc2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDesc2.setText("lblDesc2");
        lblDesc2.setBorder(javax.swing.BorderFactory.createLineBorder(null));

        lblDesc3.setForeground(new java.awt.Color(0, 0, 204));
        lblDesc3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDesc3.setText("lblDesc3");
        lblDesc3.setBorder(javax.swing.BorderFactory.createLineBorder(null));

        lblValor1.setForeground(new java.awt.Color(255, 0, 0));
        lblValor1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblValor1.setText("lblValor1");
        lblValor1.setBorder(javax.swing.BorderFactory.createLineBorder(null));

        lblValor2.setForeground(new java.awt.Color(255, 0, 0));
        lblValor2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblValor2.setText("lblValor2");
        lblValor2.setBorder(javax.swing.BorderFactory.createLineBorder(null));

        lblValor3.setForeground(new java.awt.Color(255, 0, 0));
        lblValor3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblValor3.setText("lblValor3");
        lblValor3.setBorder(javax.swing.BorderFactory.createLineBorder(null));

        lblimg4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblimg4.setBorder(javax.swing.BorderFactory.createLineBorder(null));

        lblCod4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCod4.setText("lblCod3");
        lblCod4.setBorder(javax.swing.BorderFactory.createLineBorder(null));

        lblDesc4.setForeground(new java.awt.Color(0, 0, 204));
        lblDesc4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDesc4.setText("lblDesc3");
        lblDesc4.setBorder(javax.swing.BorderFactory.createLineBorder(null));

        lblValor4.setForeground(new java.awt.Color(255, 0, 0));
        lblValor4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblValor4.setText("lblValor3");
        lblValor4.setBorder(javax.swing.BorderFactory.createLineBorder(null));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(lblCod3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(60, 60, 60)
                                        .addComponent(lblValor3, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(46, 46, 46)
                                        .addComponent(lblimg3, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(57, 57, 57)
                                .addComponent(lblimg1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(36, 36, 36)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(22, 22, 22)
                                .addComponent(lblimg4, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(lblimg2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(2, 2, 2))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(lblCod1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(lblValor1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(lblDesc1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(lblCod4, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(lblValor4, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(lblCod2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(lblValor2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(lblDesc2, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(lblDesc3, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lblDesc4, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblimg1, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblimg2, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblCod1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblValor1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblCod2, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lblValor2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDesc1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDesc2, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblimg3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblCod3, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblDesc3, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblDesc4, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblimg4, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblCod4, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblValor3, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblValor4, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(26, 26, 26)))
                .addContainerGap())
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(null));
        jPanel2.setToolTipText("Tela Principal");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Informe o Códgio");

        edtCodigoProd.setFont(new java.awt.Font("Alef", 0, 14)); // NOI18N
        edtCodigoProd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edtCodigoProdActionPerformed(evt);
            }
        });
        edtCodigoProd.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                edtCodigoProdKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                edtCodigoProdKeyTyped(evt);
            }
        });

        lblprodsel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblprodsel.setText("lblProdSel");

        btnComprar.setText("Comprar");
        btnComprar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnComprarActionPerformed(evt);
            }
        });

        btnGerenciar.setText("Gerenciar");
        btnGerenciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGerenciarActionPerformed(evt);
            }
        });

        lblimg5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblimg5.setBorder(javax.swing.BorderFactory.createLineBorder(null));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(lblimg5, javax.swing.GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(edtCodigoProd)
                        .addComponent(lblprodsel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnComprar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnGerenciar, javax.swing.GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE)
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(edtCodigoProd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblprodsel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblimg5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(btnComprar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnGerenciar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jLabel3.setFont(new java.awt.Font("Arial", 1, 42)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 0, 0));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("DRINK MACHINE");
        jLabel3.setBorder(javax.swing.BorderFactory.createLineBorder(null));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        setSize(new java.awt.Dimension(660, 487));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void edtCodigoProdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edtCodigoProdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edtCodigoProdActionPerformed

    private void edtCodigoProdKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_edtCodigoProdKeyTyped
        char key = evt.getKeyChar();
        if (key < 48 || key > 57) {
            evt.consume();
        }
    }//GEN-LAST:event_edtCodigoProdKeyTyped

    private void edtCodigoProdKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_edtCodigoProdKeyReleased
        String cod = edtCodigoProd.getText();
        ImageIcon img = new ImageIcon(prods.get(0).getImagem());
        String desc = "";
        if (cod.length() > 0) {
            Integer codProd = Integer.parseInt(cod);
            for (Produto p : prods) {
                if (p.getId() == codProd) {
                    desc = p.getDescr();
                }
            }
            lblprodsel.setText(desc);
            lblimg5.setIcon(img);
        }
    }//GEN-LAST:event_edtCodigoProdKeyReleased

    private void btnComprarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnComprarActionPerformed
        String codProd = edtCodigoProd.getText();
        Integer cod = -1;
        Object sel;
        Produto prod = null;
        FormaPgto forma = null;

        if (codProd.length() > 0) {
            cod = Integer.parseInt(codProd);
        } else {
            JOptionPane.showMessageDialog(this, "Você deve informar um Produto");
            return;
        }

        for (Produto p : prods) {
            if (p.getId() == cod) {
                prod = p;
            }
        }

        if (prod == null) {
            JOptionPane.showMessageDialog(this, "Produto inválido!");
            return;
        }

        try {
            formas = FormaPgto.buscaFormasPgto();
            Object[] opcoes = formas.stream().map(f -> f.getDescr())
                    .collect(Collectors.toList()).toArray();
            sel = JOptionPane.showInputDialog(this,
                    "Selecione a Forma de Pagamento...", "Formas de Pagamento",
                    JOptionPane.QUESTION_MESSAGE, null,
                    opcoes, opcoes[0]);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return;
        }

        for (FormaPgto f : formas) {
            if (f.getDescr().equals(sel)) {
                forma = f;
            }
        }

        if (forma != null) {
            Vendas reg = new Vendas(prod, forma);
            try {
                reg.salvar();
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this,
                        ex.getMessage());
                return;
            }

            JOptionPane.showMessageDialog(this,
                    "Venda confirmada! Retire seu produto.");
        } else {
            JOptionPane.showMessageDialog(this,
                    "Você deve informar uma Forma de Pagamento!");
        }
    }//GEN-LAST:event_btnComprarActionPerformed

    private void btnGerenciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGerenciarActionPerformed
        TelaAdmin adm = new TelaAdmin();
        adm.setVisible(true);
    }//GEN-LAST:event_btnGerenciarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelePrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelePrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelePrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelePrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelePrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnComprar;
    private javax.swing.JButton btnGerenciar;
    private javax.swing.JTextField edtCodigoProd;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lblCod1;
    private javax.swing.JLabel lblCod2;
    private javax.swing.JLabel lblCod3;
    private javax.swing.JLabel lblCod4;
    private javax.swing.JLabel lblDesc1;
    private javax.swing.JLabel lblDesc2;
    private javax.swing.JLabel lblDesc3;
    private javax.swing.JLabel lblDesc4;
    private javax.swing.JLabel lblValor1;
    private javax.swing.JLabel lblValor2;
    private javax.swing.JLabel lblValor3;
    private javax.swing.JLabel lblValor4;
    private javax.swing.JLabel lblimg1;
    private javax.swing.JLabel lblimg2;
    private javax.swing.JLabel lblimg3;
    private javax.swing.JLabel lblimg4;
    private javax.swing.JLabel lblimg5;
    private javax.swing.JLabel lblprodsel;
    // End of variables declaration//GEN-END:variables
}
